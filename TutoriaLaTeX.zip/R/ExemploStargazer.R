exlatex <- read.csv("C:/Users/lschm/Desktop/exlatex.csv")

as.data.frame(exlatex)

modeloexemplo <- lm(consumo ~ renda, data=exlatex)
summary(modeloexemplo)